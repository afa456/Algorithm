1 Requirement: Numpy, networkx

2.Overall Structure
  mst_nn.py(NN and MST), sa.py, hc.py, bnb_od.py are 5 implemented algortihms.
  main.py is the main function used for calling algorithms.
  argparser.py is used for parsing parameter in command line.

3 Running method: open terminal in 'code' folder. Statement scheme is 
$ python main.py [-MST|-Heur|LS1|LS2|BnB] -t [time] -rs[number of random seed] PATH[file name/location]

4 Take 'Atlanta.tsp' as an example(All data files are in DATA folder):
 1) for MST: $ python main.py -MST -t 600 DATA/Atlanta.tsp
 2) for Nearest Neighbor: $ python main.py -Heur -t 600 DATA/Atlanta.tsp
 3) for Branch and Bound: $ python main.py -BnB -t 600 DATA/Atlanta.tsp
 4) for hill climbing: $ python main.py -LS1 -t 600 -rs 1 DATA/Atlanta.tsp
 5) for simulated annealing: $ python main.py -LS2 -t 600 -rs 1 DATA/Atlanta.tsp
